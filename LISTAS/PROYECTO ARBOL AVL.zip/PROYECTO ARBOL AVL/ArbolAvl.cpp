#include "ArbolAVL.h"
#include <iostream>


ArbolAVL::ArbolAVL() : raiz(nullptr) {}


void ArbolAVL::agregarDistancia(int distancia) {
    raiz = insertar(raiz, distancia);
}


NodoAVL* ArbolAVL::insertar(NodoAVL* nodo, int distancia) {
    if (nodo == nullptr) {
        return new NodoAVL(distancia);
    }

    if (distancia < nodo->distancia) {
        nodo->izquierdo = insertar(nodo->izquierdo, distancia);
    } else if (distancia > nodo->distancia) {
        nodo->derecho = insertar(nodo->derecho, distancia);
    } else {
        return nodo;  
    }

    nodo->altura = 1 + std::max(obtenerAltura(nodo->izquierdo), obtenerAltura(nodo->derecho));

    int balance = obtenerFactorBalance(nodo);

 
    if (balance > 1 && distancia < nodo->izquierdo->distancia) {
        return rotarDerecha(nodo);
    }

    if (balance < -1 && distancia > nodo->derecho->distancia) {
        return rotarIzquierda(nodo);
    }

    if (balance > 1 && distancia > nodo->izquierdo->distancia) {
        nodo->izquierdo = rotarIzquierda(nodo->izquierdo);
        return rotarDerecha(nodo);
    }

    if (balance < -1 && distancia < nodo->derecho->distancia) {
        nodo->derecho = rotarDerecha(nodo->derecho);
        return rotarIzquierda(nodo);
    }

    return nodo;
}


int ArbolAVL::obtenerAltura(NodoAVL* nodo) {
    if (nodo == nullptr) {
        return 0;
    }
    return nodo->altura;
}


int ArbolAVL::obtenerFactorBalance(NodoAVL* nodo) {
    if (nodo == nullptr) {
        return 0;
    }
    return obtenerAltura(nodo->izquierdo) - obtenerAltura(nodo->derecho);
}


NodoAVL* ArbolAVL::rotarDerecha(NodoAVL* y) {
    NodoAVL* x = y->izquierdo;
    NodoAVL* T2 = x->derecho;

   
    x->derecho = y;
    y->izquierdo = T2;

    
    y->altura = std::max(obtenerAltura(y->izquierdo), obtenerAltura(y->derecho)) + 1;
    x->altura = std::max(obtenerAltura(x->izquierdo), obtenerAltura(x->derecho)) + 1;

    return x;  
}


NodoAVL* ArbolAVL::rotarIzquierda(NodoAVL* x) {
    NodoAVL* y = x->derecho;
    NodoAVL* T2 = y->izquierdo;

  
    y->izquierdo = x;
    x->derecho = T2;

 
    x->altura = std::max(obtenerAltura(x->izquierdo), obtenerAltura(x->derecho)) + 1;
    y->altura = std::max(obtenerAltura(y->izquierdo), obtenerAltura(y->derecho)) + 1;

    return y;  
}


void ArbolAVL::recorridoInorden(NodoAVL* nodo) {
    if (nodo != nullptr) {
        recorridoInorden(nodo->izquierdo);
        std::cout << nodo->distancia << " ";
        recorridoInorden(nodo->derecho);
    }
}


void ArbolAVL::mostrarDistancias() {
    recorridoInorden(raiz);
    std::cout << std::endl;
}


void ArbolAVL::mostrarArbol(sf::RenderWindow& ventana, sf::Font& fuente) {
    mostrarArbol(raiz, ventana, fuente, 400, 50, false);
}


void ArbolAVL::mostrarArbol(NodoAVL* nodo, sf::RenderWindow& ventana, sf::Font& fuente, int x, int y, bool esIzquierdo) {
    if (nodo == nullptr) {
        return;
    }

 
    sf::CircleShape circulo(30);
    circulo.setFillColor(sf::Color::Green);
    circulo.setPosition(x, y);
    ventana.draw(circulo);

    sf::Text texto;
    texto.setFont(fuente);
    texto.setString(std::to_string(nodo->distancia));
    texto.setCharacterSize(20);
    texto.setFillColor(sf::Color::White);
    texto.setPosition(x + 5, y + 5);
    ventana.draw(texto);

    
    if (nodo->izquierdo != nullptr) {
        sf::Vertex line[] = {
            sf::Vertex(sf::Vector2f(x + 30, y + 30)),
            sf::Vertex(sf::Vector2f(x - 50, y + 80))
        };
        ventana.draw(line, 2, sf::Lines);
        mostrarArbol(nodo->izquierdo, ventana, fuente, x - 100, y + 80, true);
    }
    if (nodo->derecho != nullptr) {
        sf::Vertex line[] = {
            sf::Vertex(sf::Vector2f(x + 30, y + 30)),
            sf::Vertex(sf::Vector2f(x + 80, y + 80))
        };
        ventana.draw(line, 2, sf::Lines);
        mostrarArbol(nodo->derecho, ventana, fuente, x + 100, y + 80, false);
    }
}